package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.IocEntity
import com.example.data.ScrapeLogEntity
import com.example.ui.theme.*
import com.example.utils.PythonScraperCode
import com.example.viewmodel.ScrapeState
import com.example.viewmodel.ThreatFeed
import com.example.viewmodel.ThreatScraperViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThreatScraperApp(viewModel: ThreatScraperViewModel) {
    val context = LocalContext.current
    var currentTab by remember { mutableStateOf("dashboard") } // "dashboard", "feeds", "iocs", "deploy"

    val scrapeState by viewModel.scrapeState.collectAsState()
    val allIocsCount by viewModel.allIocs.collectAsState()
    val filteredIocs by viewModel.filteredIocs.collectAsState()
    val scrapeLogs by viewModel.scrapeLogs.collectAsState()

    // Counts for dashboard
    val ipCount by viewModel.ipCount.collectAsState()
    val domainCount by viewModel.domainCount.collectAsState()
    val hashCount by viewModel.hashCount.collectAsState()
    val flaggedCount by viewModel.flaggedCount.collectAsState()

    // Reset scrape dialog state when it finishes successfully
    LaunchedEffect(scrapeState) {
        if (scrapeState is ScrapeState.Success) {
            val state = scrapeState as ScrapeState.Success
            Toast.makeText(
                context,
                "Scrape complete! Found ${state.count} items (${state.addedCount} new added).",
                Toast.LENGTH_LONG
            ).show()
        } else if (scrapeState is ScrapeState.Error) {
            val errState = scrapeState as ScrapeState.Error
            Toast.makeText(context, "Error: ${errState.message}", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "ThreatScout Logo",
                            tint = AccentTeal,
                            modifier = Modifier.size(28.dp)
                        )
                        Text(
                            text = "THREATSCOUT CORE",
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = TextLight
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.scrapeAll() },
                        modifier = Modifier.testTag("action_scrape_all")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Scrape All Feeds",
                            tint = AccentBlue
                        )
                    }
                    IconButton(
                        onClick = {
                            viewModel.clearAllData()
                            Toast.makeText(context, "Local Threat Database Cleared", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("action_clear_all")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Clear Database",
                            tint = AlertRed
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberDark,
                    titleContentColor = TextLight
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = SlateMedium,
                tonalElevation = 8.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                NavigationBarItem(
                    selected = currentTab == "dashboard",
                    label = { Text("Dashboard", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Dashboard Tab") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberDark,
                        selectedTextColor = AccentBlue,
                        indicatorColor = AccentBlue,
                        unselectedIconColor = TextGray,
                        unselectedTextColor = TextGray
                    ),
                    onClick = { currentTab = "dashboard" },
                    modifier = Modifier.testTag("tab_dashboard")
                )
                NavigationBarItem(
                    selected = currentTab == "feeds",
                    label = { Text("Feeds", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.List, contentDescription = "Feeds Tab") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberDark,
                        selectedTextColor = AccentTeal,
                        indicatorColor = AccentTeal,
                        unselectedIconColor = TextGray,
                        unselectedTextColor = TextGray
                    ),
                    onClick = { currentTab = "feeds" },
                    modifier = Modifier.testTag("tab_feeds")
                )
                NavigationBarItem(
                    selected = currentTab == "iocs",
                    label = { Text("Scraped IOCs", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Search, contentDescription = "IOCs Tab") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberDark,
                        selectedTextColor = AccentBlue,
                        indicatorColor = AccentBlue,
                        unselectedIconColor = TextGray,
                        unselectedTextColor = TextGray
                    ),
                    onClick = { currentTab = "iocs" },
                    modifier = Modifier.testTag("tab_iocs")
                )
                NavigationBarItem(
                    selected = currentTab == "deploy",
                    label = { Text("Deploy Studio", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Share, contentDescription = "Deploy Tab") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyberDark,
                        selectedTextColor = AccentTeal,
                        indicatorColor = AccentTeal,
                        unselectedIconColor = TextGray,
                        unselectedTextColor = TextGray
                    ),
                    onClick = { currentTab = "deploy" },
                    modifier = Modifier.testTag("tab_deploy")
                )
            }
        },
        containerColor = CyberDark
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Processing status banner
            if (scrapeState is ScrapeState.Loading) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter),
                    color = AccentTeal,
                    trackColor = SlateMedium
                )
            }

            Box(modifier = Modifier.fillMaxSize()) {
                when (currentTab) {
                    "dashboard" -> DashboardIndex(
                        viewModel = viewModel,
                        ipCount = ipCount,
                        domainCount = domainCount,
                        hashCount = hashCount,
                        flaggedCount = flaggedCount,
                        logs = scrapeLogs,
                        onNavigateToFeeds = { currentTab = "feeds" },
                        onNavigateToIocs = { currentTab = "iocs" }
                    )
                    "feeds" -> ThreatFeedsPage(
                        viewModel = viewModel,
                        scrapeState = scrapeState
                    )
                    "iocs" -> ScrapedIocsPage(
                        viewModel = viewModel,
                        iocs = filteredIocs
                    )
                    "deploy" -> DeployPage()
                }
            }
        }
    }
}

@Composable
fun DashboardIndex(
    viewModel: ThreatScraperViewModel,
    ipCount: Int,
    domainCount: Int,
    hashCount: Int,
    flaggedCount: Int,
    logs: List<ScrapeLogEntity>,
    onNavigateToFeeds: () -> Unit,
    onNavigateToIocs: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Status Block
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(SlateMedium, CardBackground)
                        )
                    )
                    .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "THREAT INTELLIGENCE DASHBOARD",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentTeal,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Securing endpoints by collecting Indicators of Compromise (IOCs) from live feeds. Scrape logs and analyze in real time.",
                    fontSize = 14.sp,
                    color = TextLight
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onNavigateToFeeds,
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Scrape Feeds", color = CyberDark, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onNavigateToIocs,
                        border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentTeal)
                    ) {
                        Text("View Scraped Data", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Stats Matrix (2x2 grid layout)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "COLLECTED DATA COUNTS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextGray,
                    letterSpacing = 1.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(
                        title = "IP Address",
                        count = ipCount,
                        color = AccentBlue,
                        icon = Icons.Default.Info,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stat_card_ip")
                    )
                    StatCard(
                        title = "Domain Name",
                        count = domainCount,
                        color = AccentTeal,
                        icon = Icons.Default.Home,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stat_card_domain")
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard(
                        title = "Hashes (SHA/MD5)",
                        count = hashCount,
                        color = CyberGreen,
                        icon = Icons.Default.CheckCircle,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stat_card_hashes")
                    )
                    StatCard(
                        title = "Flagged Critical",
                        count = flaggedCount,
                        color = AlertRed,
                        icon = Icons.Default.Favorite,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("stat_card_flagged")
                    )
                }
            }
        }

        // Scrape Logs Panel
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SlateMedium)
                    .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "RECENT SCRAPE LOGS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentTeal,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                if (logs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = "Logs empty",
                                tint = TextGray,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "No scrapes executed yet.",
                                fontSize = 13.sp,
                                color = TextGray
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        logs.forEach { log ->
                            ScrapeLogItemRow(log)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    count: Int,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = SlateMedium),
        border = BorderStroke(1.dp, BorderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 12.sp, color = TextGray, fontWeight = FontWeight.Bold)
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(16.dp))
            }
            Text(
                text = String.format("%,d", count),
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                color = color
            )
        }
    }
}

@Composable
fun ScrapeLogItemRow(log: ScrapeLogEntity) {
    val formatter = remember { SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()) }
    val timeString = formatter.format(Date(log.timestamp))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val bulletColor = if (log.scrapedCount > 0) CyberGreen else AlertRed
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(bulletColor)
            )
            Column {
                Text(text = log.feed, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextLight)
                Text(text = timeString, fontSize = 11.sp, color = TextGray)
            }
        }
        Text(
            text = "+${log.scrapedCount} files parsed",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = CyberGreen
        )
    }
}

@Composable
fun ThreatFeedsPage(
    viewModel: ThreatScraperViewModel,
    scrapeState: ScrapeState
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "THREAT FEEDS", fontSize = 18.sp, fontWeight = FontWeight.Black, color = TextLight)
                    Text(text = "Select feeds to query live public endpoints.", fontSize = 12.sp, color = TextGray)
                }
                Button(
                    onClick = { viewModel.scrapeAll() },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                    shape = RoundedCornerShape(6.dp),
                    enabled = scrapeState !is ScrapeState.Loading,
                    modifier = Modifier.testTag("scrape_all_feeds_btn")
                ) {
                    Text("Fetch All", fontWeight = FontWeight.Bold, color = CyberDark)
                }
            }
        }

        items(viewModel.feedsList) { feed ->
            FeedCard(
                feed = feed,
                scrapeState = scrapeState,
                onScrape = { viewModel.scrapeFeed(feed) }
            )
        }
    }
}

@Composable
fun FeedCard(
    feed: ThreatFeed,
    scrapeState: ScrapeState,
    onScrape: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SlateMedium),
        border = BorderStroke(1.dp, BorderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = feed.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = AccentBlue
                    )
                    Text(
                        text = "Source: ${feed.provider}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AccentTeal
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CardBackground)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = feed.mimeType,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextGray
                    )
                }
            }

            Text(
                text = feed.description,
                fontSize = 13.sp,
                color = TextLight
            )

            Text(
                text = feed.url,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = TextGray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(CyberDark)
                    .padding(4.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onScrape,
                    colors = ButtonDefaults.buttonColors(containerColor = CardBackground),
                    border = BorderStroke(1.dp, AccentTeal),
                    shape = RoundedCornerShape(8.dp),
                    enabled = scrapeState !is ScrapeState.Loading,
                    modifier = Modifier.testTag("scrape_${feed.name.replace(" ", "_").lowercase()}_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Trigger scrape",
                        tint = AccentTeal,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Trigger Scrape", color = TextLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun ScrapedIocsPage(
    viewModel: ThreatScraperViewModel,
    iocs: List<IocEntity>
) {
    val query by viewModel.searchQuery.collectAsState()
    val selectedType by viewModel.selectedType.collectAsState()
    val context = LocalContext.current

    val filterTypes = listOf("All", "IP Address", "Domain Name", "SHA256 Hash", "MD5 Hash", "Flagged")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column {
            Text(text = "INTELLIGENCE CONSOLE", fontSize = 18.sp, fontWeight = FontWeight.Black, color = TextLight)
            Text(text = "Search, filter, flag, and append intelligence comments.", fontSize = 12.sp, color = TextGray)
        }

        // Search Input
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.searchQuery.value = it },
            placeholder = { Text("Search IOC values, feeds, or notes...", color = TextGray) },
            prefix = { Icon(Icons.Default.Search, contentDescription = null, tint = TextGray, modifier = Modifier.size(18.dp)) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("ioc_search_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextLight,
                unfocusedTextColor = TextLight,
                focusedBorderColor = AccentBlue,
                unfocusedBorderColor = BorderColor,
                focusedContainerColor = SlateMedium,
                unfocusedContainerColor = SlateMedium
            ),
            shape = RoundedCornerShape(10.dp),
            singleLine = true
        )

        // Type Filter Pills Scrollable Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp),
                verticalArrangement = Arrangement.Center
            ) {} // Keep top list flexible
            
            // Render basic wrap layout for chips or scrollable
            // Let's show the standard flow chips in inline horizontal row:
        }

        // Let's implement Type filter pills as a lazy horizontal list!
        Box(modifier = Modifier.height(36.dp)) {
            // Standard horizontal list of filter pills can fit
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(filterTypes) { type ->
                    val isSelected = selectedType == type
                    val bgColor = if (isSelected) AccentTeal else CardBackground
                    val textColor = if (isSelected) CyberDark else TextLight
                    val borderStroke = if (isSelected) BorderStroke(0.dp, Color.Transparent) else BorderStroke(1.dp, BorderColor)

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(bgColor)
                            .clickable { viewModel.selectedType.value = type }
                            .then(
                                if (isSelected) Modifier else Modifier.border(
                                    1.dp,
                                    BorderColor,
                                    RoundedCornerShape(50)
                                )
                            )
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("filter_pill_$type")
                    ) {
                        Text(
                            text = type,
                            color = textColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // IOC Items matching filters
        if (iocs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.Info,
                        contentDescription = "No data match",
                        tint = TextGray,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No Threat Indicators Found",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextLight
                    )
                    Text(
                        text = "Trigger a feed scraping session to import live endpoints.",
                        fontSize = 13.sp,
                        color = TextGray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(iocs, key = { it.id }) { ioc ->
                    IocCard(
                        ioc = ioc,
                        onToggleFlagged = { viewModel.toggleFlagged(ioc.id, !ioc.isFlagged) },
                        onSaveNote = { note -> viewModel.addNote(ioc.id, note) },
                        onDeleteItem = { viewModel.deleteIoc(ioc.id) },
                        onCopyValue = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("IOC", ioc.value)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Copied indicator payload!", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun IocCard(
    ioc: IocEntity,
    onToggleFlagged: () -> Unit,
    onSaveNote: (String) -> Unit,
    onDeleteItem: () -> Unit,
    onCopyValue: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var noteInput by remember { mutableStateOf(ioc.note) }
    val isNoteSaved = ioc.note.isNotEmpty()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ioc_card_${ioc.id}"),
        colors = CardDefaults.cardColors(containerColor = SlateMedium),
        border = BorderStroke(
            width = 1.dp,
            color = if (ioc.isFlagged) AlertRed else BorderColor
        )
    ) {
        Column(
            modifier = Modifier
                .clickable { expanded = !expanded }
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val color = when (ioc.type) {
                        "IP Address" -> AccentBlue
                        "Domain Name" -> AccentTeal
                        else -> CyberGreen
                    }
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(50))
                            .background(color)
                    )
                    Text(
                        text = ioc.type,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = color
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = onToggleFlagged,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (ioc.isFlagged) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Flag Item",
                            tint = if (ioc.isFlagged) AlertRed else TextGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(
                        onClick = onCopyValue,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Copy Item",
                            tint = AccentTeal,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // The Malicious indicator value
            Text(
                text = ioc.value,
                fontSize = 15.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = TextLight,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Source: ${ioc.feed}",
                    fontSize = 11.sp,
                    color = AccentTeal,
                    fontWeight = FontWeight.Bold
                )

                if (isNoteSaved) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Has comments",
                            tint = AccentTeal,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "Analyst Notes",
                            fontSize = 10.sp,
                            color = AccentTeal,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    HorizontalDivider(color = BorderColor, modifier = Modifier.padding(bottom = 8.dp))

                    Text(text = "ANALYST INTELLIGENCE REMARK", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = TextGray)
                    Spacer(modifier = Modifier.height(4.dp))

                    TextField(
                        value = noteInput,
                        onValueChange = { noteInput = it },
                        placeholder = { Text("Log observation, investigations or security actions...", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = TextLight,
                            unfocusedTextColor = TextLight,
                            focusedContainerColor = CyberDark,
                            unfocusedContainerColor = CyberDark
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onDeleteItem,
                            border = BorderStroke(1.dp, AlertRed),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("Delete IOC", fontSize = 11.sp)
                        }

                        Button(
                            onClick = { onSaveNote(noteInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = AccentTeal),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("Save Note", color = CyberDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DeployPage() {
    val context = LocalContext.current
    val files = listOf(
        "main.py",
        "config.py",
        "fetcher.py",
        "parser.py",
        "validator.py",
        "storage.py",
        "requirements.txt",
        "README.md"
    )

    var selectedFile by remember { mutableStateOf("main.py") }

    val fileContent = when (selectedFile) {
        "main.py" -> PythonScraperCode.mainPy
        "config.py" -> PythonScraperCode.configPy
        "fetcher.py" -> PythonScraperCode.fetcherPy
        "parser.py" -> PythonScraperCode.parserPy
        "validator.py" -> PythonScraperCode.validatorPy
        "storage.py" -> PythonScraperCode.storagePy
        "requirements.txt" -> PythonScraperCode.requirementsTxt
        "README.md" -> PythonScraperCode.readmeMd
        else -> ""
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text(text = "GITHUB GITHUBDEPLOY STUDIO", fontSize = 18.sp, fontWeight = FontWeight.Black, color = TextLight)
                Text(text = "Copy and deploy this functional intelligence scraper directly on GitHub.", fontSize = 12.sp, color = TextGray)
            }
        }

        // Interactive Selector Row
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SlateMedium),
                border = BorderStroke(1.dp, BorderColor)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(text = "SELECT CODE MODULE TO EXPORT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextGray)
                    Spacer(modifier = Modifier.height(8.dp))

                    Box(modifier = Modifier.height(34.dp)) {
                        androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(files) { filename ->
                                val isSelected = selectedFile == filename
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) AccentTeal else CardBackground)
                                        .clickable { selectedFile = filename }
                                        .then(
                                            if (isSelected) Modifier else Modifier.border(
                                                1.dp,
                                                BorderColor,
                                                RoundedCornerShape(6.dp)
                                            )
                                        )
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                        .testTag("code_selector_$filename")
                                ) {
                                    Text(
                                        text = filename,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) CyberDark else TextLight
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Pristine Black code display terminal panel
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF070B14))
                    .border(1.dp, BorderColor, RoundedCornerShape(10.dp))
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(AlertRed))
                        Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(AccentTeal))
                        Box(modifier = Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(AccentBlue))
                    }

                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("ThreatScraperCode", fileContent)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Copied $selectedFile content!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SlateMedium),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, tint = AccentTeal, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Copy Script", color = TextLight, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = fileContent,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AccentTeal,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Friendly actions guide instruction block
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateMedium)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "AUTO-RUN ON GITHUB ACTIONS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentTeal
                )
                Text(
                    text = "1. Commit these python modules to a new public GitHub repo.\n" +
                            "2. Create a file inside your repository at `.github/workflows/scrape.yml`.\n" +
                            "3. Add the pre-configured GitHub Actions layout from the README.md.\n" +
                            "4. Your script triggers scraping workflows under a daily cron automatically, saving and formatting clean reports on your repository!",
                    fontSize = 12.sp,
                    color = TextLight,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
