package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = AccentBlue,
    secondary = AccentTeal,
    background = CyberDark,
    surface = SlateMedium,
    onPrimary = CyberDark,
    onSecondary = CyberDark,
    onBackground = TextLight,
    onSurface = TextLight,
    error = AlertRed
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    // We enforce our unified professional dark cybersecurity theme to ensure top-tier visuals!
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
