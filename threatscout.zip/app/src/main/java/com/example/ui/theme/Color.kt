package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberDark = Color(0xFF0C101B)
val SlateMedium = Color(0xFF161F33)
val CardBackground = Color(0xFF1E293B)
val AccentTeal = Color(0xFF00F5D4)
val AccentBlue = Color(0xFF00BBFF)
val CyberGreen = Color(0xFF22C55E)
val AlertRed = Color(0xFFEF4444)
val TextLight = Color(0xFFF8FAFC)
val TextGray = Color(0xFF94A3B8)
val BorderColor = Color(0xFF334155)
