package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

object NetworkFetcher {

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    suspend fun fetchFeed(url: String): Result<String> = withContext(Dispatchers.IO) {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScout/1.0 (Cybersecurity Academic Scraper)")
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Result.failure(IOException("Server error: ${response.code} ${response.message}"))
                } else {
                    val bodyString = response.body?.string()
                    if (bodyString != null) {
                        Result.success(bodyString)
                    } else {
                        Result.failure(IOException("Empty response body"))
                    }
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
