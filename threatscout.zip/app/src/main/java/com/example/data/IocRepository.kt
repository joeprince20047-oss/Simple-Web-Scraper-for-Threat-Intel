package com.example.data

import kotlinx.coroutines.flow.Flow

class IocRepository(private val iocDao: IocDao) {
    val allIocs: Flow<List<IocEntity>> = iocDao.getAllIocs()
    val scrapeLogs: Flow<List<ScrapeLogEntity>> = iocDao.getScrapeLogs()

    fun getIocsByType(type: String): Flow<List<IocEntity>> {
        return iocDao.getIocsByType(type)
    }

    fun getFlaggedIocs(): Flow<List<IocEntity>> {
        return iocDao.getFlaggedIocs()
    }

    fun searchIocs(query: String): Flow<List<IocEntity>> {
        return iocDao.searchIocs(query)
    }

    suspend fun insertIocs(items: List<IocEntity>): Int {
        val insertedIds = iocDao.insertIocs(items)
        // returns count of successfully inserted rows (i.e. not conflict ignored)
        return insertedIds.count { it != -1L }
    }

    suspend fun insertIoc(item: IocEntity): Long {
        return iocDao.insertIoc(item)
    }

    suspend fun updateIoc(item: IocEntity) {
        iocDao.updateIoc(item)
    }

    suspend fun deleteIocById(id: Long) {
        iocDao.deleteIocById(id)
    }

    suspend fun clearAllIocs() {
        iocDao.clearAllIocs()
    }

    suspend fun insertScrapeLog(log: ScrapeLogEntity) {
        iocDao.insertScrapeLog(log)
    }
}
