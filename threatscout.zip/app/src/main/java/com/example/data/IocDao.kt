package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface IocDao {
    @Query("SELECT * FROM iocs ORDER BY timestamp DESC")
    fun getAllIocs(): Flow<List<IocEntity>>

    @Query("SELECT * FROM iocs WHERE type = :type ORDER BY timestamp DESC")
    fun getIocsByType(type: String): Flow<List<IocEntity>>

    @Query("SELECT * FROM iocs WHERE isFlagged = 1 ORDER BY timestamp DESC")
    fun getFlaggedIocs(): Flow<List<IocEntity>>

    @Query("SELECT * FROM iocs WHERE value LIKE '%' || :query || '%' OR feed LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchIocs(query: String): Flow<List<IocEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIocs(items: List<IocEntity>): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIoc(item: IocEntity): Long

    @Query("DELETE FROM iocs WHERE id = :id")
    suspend fun deleteIocById(id: Long)

    @Update
    suspend fun updateIoc(item: IocEntity)

    @Query("DELETE FROM iocs")
    suspend fun clearAllIocs()

    // Log functions
    @Query("SELECT * FROM scrape_logs ORDER BY timestamp DESC LIMIT 30")
    fun getScrapeLogs(): Flow<List<ScrapeLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScrapeLog(log: ScrapeLogEntity)
}
