package com.example.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "iocs",
    indices = [Index(value = ["value"], unique = true)]
)
data class IocEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val feed: String,
    val type: String, // "IP Address", "Domain Name", "SHA256 Hash"
    val value: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFlagged: Boolean = false,
    val note: String = ""
)

@Entity(tableName = "scrape_logs")
data class ScrapeLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val feed: String,
    val scrapedCount: Int,
    val timestamp: Long = System.currentTimeMillis()
)
