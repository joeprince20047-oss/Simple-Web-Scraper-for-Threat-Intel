package com.example.data

import java.util.regex.Pattern

object IocParser {

    private val ipPattern = Pattern.compile("\\b(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3})\\b")
    
    // Domain regex targeting common TLDs + standard formats
    private val domainPattern = Pattern.compile(
        "\\b(?:[a-zA-Z0-9-]+\\.)+(com|net|org|ru|cn|xyz|info|biz|cc|su|co|io|top|gq|cf|ga|ml)\\b",
        Pattern.CASE_INSENSITIVE
    )
    
    // Hash regex targeting SHA256 and MD5
    private val sha256Pattern = Pattern.compile("\\b([a-fA-F0-9]{64})\\b")
    private val md5Pattern = Pattern.compile("\\b([a-fA-F0-9]{32})\\b")

    fun extractIocs(rawText: String, feedName: String): List<IocEntity> {
        val iocs = mutableListOf<IocEntity>()
        val lines = rawText.lineSequence()
        val now = System.currentTimeMillis()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty() || trimmed.startsWith("#") || trimmed.startsWith("//")) {
                continue
            }

            // 1. Matches SHA256
            val shaMatcher = sha256Pattern.matcher(trimmed)
            if (shaMatcher.find()) {
                val value = shaMatcher.group(1)
                iocs.add(IocEntity(feed = feedName, type = "SHA256 Hash", value = value.lowercase(), timestamp = now))
                continue
            }

            // 2. Matches MD5
            val md5Matcher = md5Pattern.matcher(trimmed)
            if (md5Matcher.find()) {
                val value = md5Matcher.group(1)
                iocs.add(IocEntity(feed = feedName, type = "MD5 Hash", value = value.lowercase(), timestamp = now))
                continue
            }

            // 3. Extract IP if present
            val ipMatcher = ipPattern.matcher(trimmed)
            var foundIp = false
            while (ipMatcher.find()) {
                val ip = ipMatcher.group(1)
                if (ip != null && isValidPublicIp(ip)) {
                    iocs.add(IocEntity(feed = feedName, type = "IP Address", value = ip, timestamp = now))
                    foundIp = true
                }
            }

            // If we found an IP in the line (e.g. hosting URL), we might not want to extract domain. But let's check for Domain.
            if (!foundIp) {
                val domainMatcher = domainPattern.matcher(trimmed)
                if (domainMatcher.find()) {
                    val domain = domainMatcher.group(0)
                    if (domain != null && !domain.equals("localhost", ignoreCase = true)) {
                        iocs.add(IocEntity(feed = feedName, type = "Domain Name", value = domain.lowercase(), timestamp = now))
                    }
                }
            }
        }

        // Deduplicate locally before returning
        return iocs.distinctBy { it.value }
    }

    private fun isValidPublicIp(ip: String): Boolean {
        val parts = ip.split(".")
        if (parts.size != 4) return false
        
        try {
            val p1 = parts[0].toInt()
            val p2 = parts[1].toInt()
            val p3 = parts[2].toInt()
            val p4 = parts[3].toInt()

            if (p1 !in 0..255 || p2 !in 0..255 || p3 !in 0..255 || p4 !in 0..255) {
                return false
            }

            // Loopback
            if (p1 == 127) return false

            // RFC1918 Private Ranges
            // 10.0.0.0 - 10.255.255.255
            if (p1 == 10) return false
            
            // 172.16.0.0 - 172.31.255.255
            if (p1 == 172 && p2 in 16..31) return false
            
            // 192.168.0.0 - 192.168.255.255
            if (p1 == 192 && p2 == 168) return false

            // Link local (169.254.x.x)
            if (p1 == 169 && p2 == 254) return false

            return true
        } catch (e: NumberFormatException) {
            return false
        }
    }
}
