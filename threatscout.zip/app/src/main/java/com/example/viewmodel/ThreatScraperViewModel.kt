package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface ScrapeState {
    object Idle : ScrapeState
    object Loading : ScrapeState
    data class Success(val count: Int, val addedCount: Int) : ScrapeState
    data class Error(val message: String) : ScrapeState
}

data class ThreatFeed(
    val name: String,
    val provider: String,
    val url: String,
    val description: String,
    val mimeType: String
)

class ThreatScraperViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: IocRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = IocRepository(database.iocDao())
    }

    // Standard public feeds definition
    val feedsList = listOf(
        ThreatFeed(
            name = "URLhaus",
            provider = "abuse.ch",
            url = "https://urlhaus.abuse.ch/downloads/text/",
            description = "Active malicious URLs used for malware distribution.",
            mimeType = "Plain Text / URLs"
        ),
        ThreatFeed(
            name = "Feodo Tracker",
            provider = "abuse.ch",
            url = "https://feodotracker.abuse.ch/downloads/ipblocklist.txt",
            description = "IP blocklist targeting host server botnet C2 infrastructure.",
            mimeType = "IP List"
        ),
        ThreatFeed(
            name = "SSL Blacklist",
            provider = "abuse.ch",
            url = "https://sslbl.abuse.ch/blacklist/sslipblacklist.txt",
            description = "Consolidated SSL certificates linked to malicious traffic.",
            mimeType = "IP List / Malicious"
        )
    )

    // Scraping status
    private val _scrapeState = MutableStateFlow<ScrapeState>(ScrapeState.Idle)
    val scrapeState: StateFlow<ScrapeState> = _scrapeState.asStateFlow()

    // Filters and search queries
    val searchQuery = MutableStateFlow("")
    val selectedType = MutableStateFlow("All") // "All", "IP Address", "Domain Name", "SHA256 Hash", "MD5 Hash", "Flagged"

    // Raw sources from repository
    val allIocs: StateFlow<List<IocEntity>> = repository.allIocs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scrapeLogs: StateFlow<List<ScrapeLogEntity>> = repository.scrapeLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Combined live reactive filtered list
    val filteredIocs: StateFlow<List<IocEntity>> = combine(
        allIocs,
        searchQuery,
        selectedType
    ) { list, query, type ->
        var result = list
        if (type != "All") {
            result = if (type == "Flagged") {
                result.filter { it.isFlagged }
            } else {
                result.filter { it.type == type }
            }
        }
        if (query.isNotEmpty()) {
            val q = query.trim()
            result = result.filter { 
                it.value.contains(q, ignoreCase = true) || it.feed.contains(q, ignoreCase = true) || it.note.contains(q, ignoreCase = true)
            }
        }
        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Live counts for dashboard visual cards
    val ipCount: StateFlow<Int> = allIocs.map { list -> list.count { it.type == "IP Address" } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val domainCount: StateFlow<Int> = allIocs.map { list -> list.count { it.type == "Domain Name" } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val hashCount: StateFlow<Int> = allIocs.map { list -> list.count { it.type.contains("Hash") } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val flaggedCount: StateFlow<Int> = allIocs.map { list -> list.count { it.isFlagged } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Scraping trigger
    fun scrapeFeed(feed: ThreatFeed) {
        viewModelScope.launch {
            _scrapeState.value = ScrapeState.Loading
            
            val result = NetworkFetcher.fetchFeed(feed.url)
            result.onSuccess { rawText ->
                val parsedItems = IocParser.extractIocs(rawText, feed.name)
                if (parsedItems.isEmpty()) {
                    _scrapeState.value = ScrapeState.Error("No valid indicators detected in response. Check the feed format.")
                    return@onSuccess
                }

                // Batch insert into database
                val newlyAdded = repository.insertIocs(parsedItems)
                
                // Save log
                repository.insertScrapeLog(ScrapeLogEntity(feed = feed.name, scrapedCount = parsedItems.size))
                
                _scrapeState.value = ScrapeState.Success(
                    count = parsedItems.size, 
                    addedCount = newlyAdded
                )
            }.onFailure { exception ->
                _scrapeState.value = ScrapeState.Error(exception.localizedMessage ?: "Failed to reach server")
            }
        }
    }

    fun scrapeAll() {
        viewModelScope.launch {
            _scrapeState.value = ScrapeState.Loading
            var totalCount = 0
            var totalAdded = 0
            val errors = mutableListOf<String>()

            for (feed in feedsList) {
                val result = NetworkFetcher.fetchFeed(feed.url)
                result.onSuccess { rawText ->
                    val parsedItems = IocParser.extractIocs(rawText, feed.name)
                    if (parsedItems.isNotEmpty()) {
                        val added = repository.insertIocs(parsedItems)
                        totalCount += parsedItems.size
                        totalAdded += added
                        repository.insertScrapeLog(ScrapeLogEntity(feed = feed.name, scrapedCount = parsedItems.size))
                    }
                }.onFailure { exception ->
                    errors.add("${feed.name}: ${exception.localizedMessage ?: "timeout"}")
                }
            }

            if (errors.size == feedsList.size) {
                _scrapeState.value = ScrapeState.Error("All feeds failed to fetch. Check connection.\n" + errors.joinToString("\n"))
            } else {
                _scrapeState.value = ScrapeState.Success(count = totalCount, addedCount = totalAdded)
            }
        }
    }

    fun toggleFlagged(id: Long, isFlagged: Boolean) {
        viewModelScope.launch {
            val ioc = allIocs.value.firstOrNull { it.id == id }
            if (ioc != null) {
                repository.updateIoc(ioc.copy(isFlagged = isFlagged))
            }
        }
    }

    fun addNote(id: Long, note: String) {
        viewModelScope.launch {
            val ioc = allIocs.value.firstOrNull { it.id == id }
            if (ioc != null) {
                repository.updateIoc(ioc.copy(note = note))
            }
        }
    }

    fun deleteIoc(id: Long) {
        viewModelScope.launch {
            repository.deleteIocById(id)
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllIocs()
            _scrapeState.value = ScrapeState.Idle
        }
    }

    fun resetScrapeState() {
        _scrapeState.value = ScrapeState.Idle
    }
}
