package com.example.utils

object PythonScraperCode {

    val configPy = """
# config.py - Configuration File
# Centralises all threat scraper settings. No logic, only data.

FEEDS = {
    "urlhaus": "https://urlhaus.abuse.ch/downloads/text/",
    "feodotracker": "https://feodotracker.abuse.ch/downloads/ipblocklist.txt",
    "sslblacklist": "https://sslbl.abuse.ch/blacklist/sslipblacklist.txt"
}

OUTPUT_DIR = "output/"
REQUEST_TIMEOUT = 10  # seconds
MAX_RETRIES = 3
DEFAULT_FORMAT = "json"  # json | csv | txt
"""

    val fetcherPy = """
# fetcher.py - Network Layer
# Responsible for all HTTP communication. Returns raw text.

import time
import requests

class FetchError(Exception):
    ""${'"'}Custom exception raised on permanent web request failures.""${'"'}
    pass

def fetch_feed(url):
    ""${'"'}
    Performs an HTTP GET request with customized User-Agent headers
    and exponential backoff retry.
    ""${'"'}
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) ThreatScoutScraper/1.0 (Ethical Threat Research)"
    }
    
    timeout = 10
    retries = 3
    backoff = 2
    
    for attempt in range(retries):
        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            if response.status_code == 200:
                return response.text
            else:
                print(f"[!] Warning: Received status code {response.status_code} for {url}. Retrying...")
        except requests.RequestException as e:
            print(f"[!] Request Exception: {e}. Retrying in {backoff} seconds...")
            
        time.sleep(backoff)
        backoff *= 2
        
    raise FetchError(f"Failed to fetch content from {url} after {retries} attempts.")
"""

    val parserPy = """
# parser.py - IOC Extraction
# Uses regex patterns to scan raw feed response text.

import re

# Precise regex patterns defined in specifications
IP_PATTERN = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
DOMAIN_PATTERN = re.compile(
    r"\b(?:[a-zA-Z0-9-]+\.)+(?:com|net|org|ru|cn|info|xyz|biz|cc|su|co|io|top)\b",
    re.IGNORECASE
)
SHA256_PATTERN = re.compile(r"\b([a-fA-F0-9]{64})\b")

def extract_iocs(text):
    ""${'"'}
    Applies regex patterns against raw text lines and extracts 
    IPs, domains, and sha256 hashes.
    ""${'"'}
    iocs = {
        "ips": [],
        "domains": [],
        "hashes": []
    }
    
    lines = text.split("\n")
    for line in lines:
        line = line.strip()
        # Skip comment lines
        if not line or line.startswith("#") or line.startswith("//"):
            continue
            
        # 1. Matches SHA256 hashes
        hashes_found = SHA256_PATTERN.findall(line)
        if hashes_found:
            for h in hashes_found:
                iocs["hashes"].append(h.lower())
            continue  # Avoid matching file hashes as domain parts
            
        # 2. Matches IP Addresses
        ips_found = IP_PATTERN.findall(line)
        if ips_found:
            for ip in ips_found:
                iocs["ips"].append(ip)
            continue
            
        # 3. Matches Domain Names
        domains_found = DOMAIN_PATTERN.findall(line)
        if domains_found:
            for d in domains_found:
                iocs["domains"].append(d.lower())
                
    return iocs
"""

    val validatorPy = """
# validator.py - Validation & Deduplication
# Deduplicates listings and filters out private RFC1918 networks.

def is_valid_public_ip(ip):
    ""${'"'}
    Returns True if an IP is a valid public IPv4 address,
    excluding RFC1918 private ranges and loopback.
    ""${'"'}
    try:
        parts = [int(p) for p in ip.split(".")]
        if len(parts) != 4:
            return False
            
        # Check standard byte ranges
        if any(p < 0 or p > 255 for p in parts):
            return False
            
        # Loopback
        if parts[0] == 127:
            return False
            
        # RFC1918 Private ranges:
        # 10.0.0.0/8
        if parts[0] == 10:
            return False
        # 172.16.0.0/12
        if parts[0] == 172 and (16 <= parts[1] <= 31):
            return False
        # 192.168.0.0/16
        if parts[0] == 192 and parts[1] == 168:
            return False
            
        return True
    except (ValueError, IndexError):
        return False

def validate_iocs(ioc_dict):
    ""${'"'}
    Validates and deduplicates the indicators of compromise.
    Converts list values to sorted deduplicated collections.
    ""${'"'}
    validated = {
        "ips": [],
        "domains": [],
        "hashes": []
    }
    
    # Deduplicate and validate IPs
    raw_ips = ioc_dict.get("ips", [])
    unique_ips = set(raw_ips)
    valid_ips = [ip for ip in unique_ips if is_valid_public_ip(ip)]
    validated["ips"] = sorted(valid_ips)
    
    # Deduplicate domains (and exclude obvious false positives like common APIs)
    raw_domains = ioc_dict.get("domains", [])
    valid_domains = [d for d in set(raw_domains) if d != "localhost"]
    validated["domains"] = sorted(valid_domains)
    
    # Deduplicate hashes
    raw_hashes = ioc_dict.get("hashes", [])
    validated["hashes"] = sorted(list(set(raw_hashes)))
    
    return validated
"""

    val storagePy = """
# storage.py - Serialization / Output Layer
# Serializes indicators to JSON, CSV, or plain TXT files.

import os
import json
import csv
from datetime import datetime

def save_json(iocs, feed_name, filepath):
    ""${'"'}Writes pretty-printed JSON representation with timestamp metadata""${'"'}
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    data = {
        "generated": datetime.utcnow().isoformat() + "Z",
        "feed": feed_name,
        "counts": {
            "ips": len(iocs["ips"]),
            "domains": len(iocs["domains"]),
            "hashes": len(iocs["hashes"])
        },
        "iocs": iocs
    }
    
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"[*] Successfully saved {sum(data['counts'].values())} IOCs to: {filepath}")

def save_csv(iocs, filepath):
    ""${'"'}Writes flat spreadsheet row entries of format [Type, Value]""${'"'}
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Type", "Value"])
        
        for ip in iocs["ips"]:
            writer.writerow(["IP Address", ip])
        for domain in iocs["domains"]:
            writer.writerow(["Domain Name", domain])
        for h in iocs["hashes"]:
            writer.writerow(["SHA256 Hash", h])
            
    total_rows = len(iocs["ips"]) + len(iocs["domains"]) + len(iocs["hashes"])
    print(f"[*] Successfully saved {total_rows} entries to: {filepath}")

def save_txt(iocs, filepath):
    ""${'"'}Writes one line text entries grouped together with section headers""${'"'}
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, "w", encoding="utf-8") as f:
        if iocs["ips"]:
            f.write("=== IP ADDRESSES ===\n")
            for ip in iocs["ips"]:
                f.write(f"{ip}\n")
            f.write("\n")
            
        if iocs["domains"]:
            f.write("=== DOMAIN NAMES ===\n")
            for domain in iocs["domains"]:
                f.write(f"{domain}\n")
            f.write("\n")
            
        if iocs["hashes"]:
            f.write("=== FILE HASHES ===\n")
            for h in iocs["hashes"]:
                f.write(f"{h}\n")
            f.write("\n")
            
    print(f"[*] Successfully saved sorted lists to format TXT: {filepath}")
"""

    val mainPy = """
# main.py - CLI Scraper Orchestrator (Entry Point)
# Provides flexible command line options supporting complete flow.

import argparse
import sys
import os

import config
import fetcher
import parser
import validator
import storage

def scrape_single_feed(feed_name, output_dir, file_format):
    if feed_name not in config.FEEDS:
        print(f"[!] Error: Specified feed '{feed_name}' is not defined in config FEEDS.")
        return False
        
    url = config.FEEDS[feed_name]
    print(f"[*] Initiating scrape of feed: {feed_name}")
    print(f"[*] Downloading: {url}")
    
    try:
        raw_data = fetcher.fetch_feed(url)
        print(f"[*] Received raw download containing {len(raw_data)} chars.")
        
        # Parse and Extract
        extracted_iocs = parser.extract_iocs(raw_data)
        
        # Validate and Deduplicate
        clean_iocs = validator.validate_iocs(extracted_iocs)
        
        # Write Output
        filename = f"iocs_{feed_name}.{file_format}"
        out_path = os.path.join(output_dir, filename)
        
        if file_format == "json":
            storage.save_json(clean_iocs, feed_name, out_path)
        elif file_format == "csv":
            storage.save_csv(clean_iocs, out_path)
        else:
            storage.save_txt(clean_iocs, out_path)
            
        return True
    except Exception as e:
        print(f"[!] Pipeline Error executing '{feed_name}': {e}")
        return False

def main():
    parser = argparse.ArgumentParser(
        description="Simple Threat Intelligence Web Scraper & Collector CLI Console."
    )
    parser.add_argument(
        "--feed",
        default="urlhaus",
        choices=list(config.FEEDS.keys()),
        help="Target threat intelligence feed to scrape."
    )
    parser.add_argument(
        "--format",
        default=config.DEFAULT_FORMAT,
        choices=["json", "csv", "txt"],
        help="Desired serialization format saving output files."
    )
    parser.add_argument(
        "--output",
        default=config.OUTPUT_DIR,
        help="Local subdirectory path where output files are written."
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Runs scrape sequence covering ALL configured feeds sequentially."
    )
    
    args = parser.parse_args()
    
    if args.all:
        print("[*] Initiating scraping cycle across ALL configured sources:")
        success_count = 0
        for name in config.FEEDS.keys():
            if scrape_single_feed(name, args.output, args.format):
                success_count += 1
        print(f"[*] Cycle finished. Scraped {success_count}/{len(config.FEEDS)} feeds successfully.")
    else:
        scrape_single_feed(args.feed, args.output, args.format)

if __name__ == "__main__":
    main()
"""

    val requirementsTxt = """
requests>=2.28.0
urllib3>=1.26.0
"""

    val readmeMd = """
# Simple Web Scraper for Threat Intelligence
Automated Indicator of Compromise (IOC) collector from public threat intelligence feeds (e.g. abuse.ch, URLhaus, Feodo Tracker, SSL Blacklist).

## Project Architecture
This lightweight modular python application executes an automated feed scraping pipeline:
1. **Fetch**: Uses `requests` with exponential backoff and localized `User-Agent` configs.
2. **Parse**: Applies regex patterns to extract IP Addresses, Domains, and SHA256 hashes from raw bodies.
3. **Validate**: Deduplicates listings and filters standard RFC1918 private IP addresses.
4. **Store**: Serializes validated threat intel list into standard `json`, `csv`, or `txt` files.

## Installation & Setup
1. Clone this repository or locate the downloadable files:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the scraping script:
   ```bash
   # Scrape the default URLhaus feed and save to output/iocs_urlhaus.json
   python main.py

   # Scrape Feodo Tracker and export as CSV
   python main.py --feed feodotracker --format csv

   # Run automated cycle scraping across ALL feeds
   python main.py --all
   ```

## Deploying on GitHub Actions / Pages
You can easily automate this tool to run daily and publish the output to GitHub Pages:
1. Store this repository under your GitHub account.
2. Setup a daily cron trigger under `.github/workflows/scrape.yml`:
```yaml
name: Global Threat Intel Scraping Cron

on:
  schedule:
    - cron: '0 0 * * *' # Every day at midnight
  workflow_dispatch: # Enable running manually in actions tab

jobs:
  scrape-and-publish:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v3

      - name: Setup Python environment
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Install active dependencies
        run: pip install -r requirements.txt

      - name: Execute Threat Scraping pipeline
        run: python main.py --all --format json --output output/

      - name: Deploy output feeds to gh-pages branch
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{"$"}}{{ secrets.GITHUB_TOKEN }}
          publish_dir: ./output
```
"""
}
